<?php
/**
 * The template for displaying Listing single page.
 *
 */
	get_header();

	get_template_part( 'templates/listing_detail2' );
	
	get_footer();
	 