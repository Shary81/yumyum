<?php

// This folder should be writable. The setup wizard places content in here.